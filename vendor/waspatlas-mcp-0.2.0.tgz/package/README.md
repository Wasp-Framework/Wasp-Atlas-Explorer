# Wasp Atlas MCP

Local desktop MCP control of **Wasp Atlas in an existing browser tab**, including
ChatGPT's built-in browser. Version 0.2 no longer launches a separate Chromium
window. The Atlas application owns the model, camera and renderer; the MCP only
forwards explicit commands to the selected tab.

## Setup

Requires Node.js 22+, this repository, and an Atlas Explorer checkout with its
0.2 local companion adapter. Both checkouts need `npm ci`. The Explorer pins the
shared bridge package in `vendor/`; it does not require a sibling MCP checkout to
build or run manually.

```sh
git clone https://github.com/Wasp-Framework/waspatlas-mcp.git
git clone https://github.com/Wasp-Framework/Wasp-Atlas-Explorer.git
cd waspatlas-mcp
npm ci
# Run npm ci in the Explorer checkout as well.
```

Configure a local stdio MCP host using absolute paths. For JSON configuration:

```json
{
  "mcpServers": {
    "waspatlas": {
      "command": "/absolute/path/to/node",
      "args": ["/absolute/path/to/waspatlas-mcp/src/index.js"],
      "env": {
        "WASPATLAS_APP_DIR": "/absolute/path/to/Wasp-Atlas-Explorer"
      }
    }
  }
}
```

The MCP host starts the stdio process. **Reconnect/restart the existing Atlas MCP
after updating**, so its tools and instructions reload. There are now **11 tools**,
including `import_dataset` and `list_instances`.

Ask the agent to call `open_atlas`, then **open the returned URL in ChatGPT's
built-in browser**. The default local URL is `http://127.0.0.1:5185/?mcp=1`.
`open_atlas` prepares the local app and returns the URL; it does not call an OS
browser opener or start Chromium. When no tab is connected, its result has
`connected: false` and `revision: null`. After the page connects, call `open_atlas`
again or `list_instances` to inspect it. Model commands then operate in that tab.
Opening this URL through an ordinary system-browser link is also possible, but
is not required. If the host's built-in browser tool is unavailable, the MCP
cannot itself restore that host capability.

By default the MCP starts the local Atlas server when needed. Set
`WASPATLAS_APP_DIR` explicitly, or keep the Explorer in a sibling folder named
`Wasp-Atlas-Explorer` or `Wasp-Atas-Explorer`. `WASPATLAS_PORT` changes the default
5185 port. A busy port is refused rather than silently connecting elsewhere.
The local server fetches the normal public Atlas catalog; dataset files are
loaded only when requested.

To run the app independently and retain its server across MCP restarts:

```sh
# In the Explorer checkout
npm run dev:control
```

Set `WASPATLAS_AUTOSTART=0` in the MCP environment to require an already-running
control server. Normal `npm run dev`, production and preview builds do not enable
the desktop-control transport. `?mcp=1` opts the tab into Atlas's command interface.
The production website URL is not a local bridge or a remote HTTPS MCP endpoint.

No Playwright/Chromium installation is needed for normal MCP use. Playwright is a
**development-only dependency** used by disposable browser integration tests.
The old `WASPATLAS_URL`, `WASPATLAS_HEADLESS` and `setup:browser` workflow no longer
select or create an external browser.

## Custom datasets

Use `import_dataset` with the latest opaque `expectedRevision` and **exactly one**
of:

- `path`: a JSON file on the computer running this local MCP; use an absolute
  path. The MCP reads it and transfers the data to the selected Atlas tab.
- `data`: a WASP aggregation JSON object supplied directly to the tool.

Example tool arguments:

```json
{
  "path": "/absolute/path/to/my-dataset.json",
  "expectedRevision": "copy-the-current-revision",
  "startEmpty": false
}
```

Optional fields are `name`, `byPart` (part names mapped to six-digit hex colors),
`filename` for inline data, and `instanceId`. `startEmpty: false` preserves supplied
placed instances; `true` starts with the imported parts and rules but no placed
assembly. Empty imports stay empty and receive no random growth. The returned
summary includes import compatibility warnings.

Imports use the **same sanitizer and loader as Atlas's upload UI**. Core-supported
parts, stock, attributes, graph state and serialization remain governed by the
installed WaspJS. Unsupported constraints are rejected. A Mode-0 copy can remove
unsupported Field data and reports the same conversion warnings as the UI; the
source file is not changed. Validation finishes before the active upload is
replaced. Stale revisions, expired commands, invalid files and interactive growth
prevent replacement.

Files are capped at 64 MiB including transport overhead. A ChatGPT attachment must
be available as a local host file or supplied as JSON; the local server cannot
read a file that exists only in another sandbox. Imports stay in the current
Atlas tab's memory and **do not upload to the public Atlas collection or GitHub**.
Export before reloading or closing the tab; a custom upload is not persisted by
this integration.

## Tools

| Tool                 | Purpose                                                                        |
| -------------------- | ------------------------------------------------------------------------------ |
| `open_atlas`         | Prepare the app and return its browser URL, or inspect/select a connected tab. |
| `list_instances`     | List connected tabs with exact instance IDs, URLs and status.                  |
| `list_datasets`      | Search/page the normal public Atlas catalog.                                   |
| `open_dataset`       | Load a catalog slug, optionally clearing its example assembly.                 |
| `import_dataset`     | Load a custom JSON file or object through Atlas upload validation.             |
| `inspect_assembly`   | Read summary, base parts, placed parts or rules without meshes.                |
| `preview_placements` | Query one part at an exact parent connection.                                  |
| `place_part`         | Seed an empty assembly or attach with all three connection IDs.                |
| `remove_part`        | Remove a leaf using the Atlas UI helper.                                       |
| `export_assembly`    | Return the same Atlas Light JSON as the Download button.                       |
| `snapshot_viewer`    | Return a native PNG from the actual tab's renderer and camera.                 |

Only a sole connected tab is selected implicitly. With multiple tabs, choose an
exact `instanceId` from `list_instances`; tools accept it as an optional argument.
A previously selected live tab remains selected. No arbitrary browser is attached
through a debugging port, and disconnecting the MCP never closes user tabs.

Model edits need the latest opaque `expectedRevision` from inspection or the
previous successful edit. Manual edits, dataset loads and document reloads
invalidate old tokens. Rejected edits and snapshots do not advance the revision.
Commands are queued per tab and checked for expiry before model commits. After a
timeout or disconnect, inspect before retrying because the outcome may be unknown.

Inspect part names and connections before placing. A seed requires an empty
assembly; attaching requires `parentPartId`, `connectionId` and `connectionBId`
together. Connection IDs are authored Wasp slots, not inferred physical ports.
Coordinates retain dataset units. Leaf-only removal, collision checks, finite
stock and import compatibility match Atlas's existing helpers and WaspJS runtime.
This change does not add routing, random-growth tools, assembly split/join or
Configurator-specific features.

## Snapshots

Snapshots retain the current camera unless `view` or `camera` is specified.
Presets are `isometric`, `top`, `bottom`, `front`, `back`, `left`, `right`; they fit
placed geometry. Z is up except for the top/bottom presets, which use +Y image up.
An absolute camera uses dataset coordinates:

```json
{
  "camera": {
    "position": [6, -6, 5],
    "target": [1, 1, 0],
    "up": [0, 0, 1],
    "fov": 45
  }
}
```

The image is copied from the existing renderer in the same browser task as its
camera/count metadata. No second model, geometry quota or screenshot scene is
created. A custom camera can naturally miss the assembly.

## Connection and lifecycle

The companion and Vite plugin live here; the Explorer supplies its existing
application commands. Browser tabs use the same local Vite HMR socket. The MCP
uses a separate authenticated loopback HTTP route. It never exposes a remote MCP
endpoint or publishes the local editor.

A rotating bearer token is stored in
`~/.local/state/waspatlas-mcp/connection.json`, with owner-only file permissions.
It is denied by Vite's file server. Browser-origin HTTP control requests and
cross-origin websocket upgrades are rejected; replies must come from the socket
that received the command. Never commit or share the connection file. To isolate
checkouts, set the same absolute `WASPATLAS_CONNECTION_FILE` in both app and MCP
environments.

If the MCP started the app server, stopping the MCP stops that server. User tabs
are left open; export before a reload/restart that would discard in-memory state.
For a persistent local app server, use `npm run dev:control` independently.

### Troubleshooting

- **No connected tab:** open the URL returned by `open_atlas` in ChatGPT's browser,
  not the hosted production website. Check `list_instances`.
- **App not found:** set `WASPATLAS_APP_DIR` to the Explorer checkout and run
  `npm ci` in both repositories. The updated Explorer adapter is required.
- **Port in use:** use the existing `dev:control` server, stop an old server, or
  set `WASPATLAS_PORT` to a free port.
- **Old nine-tool interface / external Chromium:** restart or reconnect the MCP
  host to load version 0.2.0. Updating source does not replace an already-running
  stdio process or refresh the host's cached tool list.
- **Stale revision:** inspect the current assembly and use its returned token.
- **Custom import fails:** supply a complete WASP aggregation object rather than
  a compact unsupported export, and read the returned validation diagnostics.
- **No Node executable:** use the full path returned by `command -v node`.

## Development and verification

```sh
npm ci
# Test-only dependency, not needed for normal use:
npx playwright install chromium
npm test
npm run format:check
```

Tests run real stdio MCP calls through the HTTP/HMR bridge into an independently
opened disposable browser tab with the actual Atlas renderer. They cover custom
file/data imports, Mode-0 notices, invalid/stale import rejection, preserved and
empty assemblies, manual UI revisions, explicit placement, snapshots, exports,
multiple tabs, reconnects and leaving tabs open on disconnect. Separate tests
cover autostart, authentication, credential protection, websocket origin checks,
queue expiry and reply ownership.

With an independently running control server and a browser tab already open,
`npm run check:web` is a **read-only** connection check. It does not launch a
browser or replace the assembly.

To refresh the Explorer's pinned bridge snapshot:

```sh
npm pack --pack-destination /absolute/path/to/Wasp-Atlas-Explorer/vendor
# In the Explorer:
npm install --save-dev ./vendor/waspatlas-mcp-0.2.0.tgz
npm test
npm run typecheck
npm run build
```

This package is private; packing is local and does not publish to npm.
