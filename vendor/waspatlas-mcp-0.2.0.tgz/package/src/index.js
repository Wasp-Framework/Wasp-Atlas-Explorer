/** Local stdio entry point. The MCP host owns this process and its local companion server. */
import { serveStdio } from "@modelcontextprotocol/server/stdio";
import { createServer } from "./server.js";

const handle = serveStdio(createServer, {
  onerror: (error) => console.error(error),
});
for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => void handle.close());
}
