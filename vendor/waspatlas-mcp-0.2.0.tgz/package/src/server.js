/** All assembly commands execute in the user's selected Atlas tab. */
import { McpServer } from "@modelcontextprotocol/server";
import * as z from "zod/v4";
import { basename, resolve } from "node:path";
import { AtlasBrowser } from "./browser.js";
import { readJSON } from "./control.js";
import { controlTools, pagination, expectedRevision } from "./protocol.js";

export function createServer({ browser = new AtlasBrowser() } = {}) {
  const server = new McpServer(
    { name: "waspatlas-mcp", version: "0.2.0" },
    {
      instructions:
        "Use open_atlas to get the local Atlas URL, then open it in ChatGPT’s built-in browser. Never launch an external browser. The MCP controls that existing tab and never owns a second model. If there are multiple tabs use list_instances and pass an exact instanceId. Import custom WASP JSON with import_dataset using a local path or JSON data; inputs are validated using Atlas upload helpers. Inspect names and connection slots before explicitly placing. Model edits need the latest opaque expectedRevision, including manual changes. Empty datasets stay empty, without random growth. Removal remains leaf-only as in Atlas. Coordinates retain dataset units. After a timeout inspect before retrying: outcome may be unknown. Export before reloading or closing a tab.",
    },
  );
  let pending = Promise.resolve();
  server.server.onclose = () =>
    void browser.close().catch((error) => console.error(error));
  function tool(name, description, schema, action, readOnly = false) {
    server.registerTool(
      name,
      {
        description,
        inputSchema: schema,
        outputSchema: z.object({
          revision: z.string().nullable(),
          value: z.unknown(),
          diagnostics: z.array(
            z.object({ code: z.string(), message: z.string() }),
          ),
        }),
        annotations: {
          readOnlyHint: readOnly,
          destructiveHint: [
            "open_dataset",
            "import_dataset",
            "remove_part",
          ].includes(name),
          openWorldHint: true,
        },
      },
      (args) => {
        const call = pending.then(async () => {
          let body, image;
          try {
            body = await action(args);
            if (name === "snapshot_viewer") {
              const { png, ...metadata } = body.value;
              image = { type: "image", mimeType: "image/png", data: png };
              body.value = metadata;
            }
            body.diagnostics = [];
          } catch (error) {
            const status = await browser.status().catch(() => null);
            body = {
              revision: status?.revision ?? null,
              value: null,
              diagnostics: [
                {
                  code: error.message.includes("stale_revision")
                    ? "stale_revision"
                    : "atlas_error",
                  message: error.message,
                },
              ],
            };
          }
          return {
            structuredContent: body,
            content: [
              { type: "text", text: JSON.stringify(body) },
              ...(image ? [image] : []),
            ],
            isError: body.value === null,
          };
        });
        pending = call.catch(() => {});
        return call;
      },
    );
  }
  const instance = {
    instanceId: z
      .uuid()
      .optional()
      .describe(
        "Exact Atlas browser tab id, required when multiple tabs are connected.",
      ),
  };
  const schema = (name) => controlTools[name].extend(instance);
  const command = (name) => (args) => browser.execute(name, args);
  tool(
    "open_atlas",
    "Prepare Atlas and return its URL. Open that URL in ChatGPT’s built-in browser; this never launches an external browser. If a tab is connected, inspect its current status.",
    z.object(instance).strict(),
    async (args) => {
      const status = await browser.open(args);
      return { revision: status.revision ?? null, value: status };
    },
    true,
  );
  tool(
    "list_instances",
    "List Atlas tabs connected to the local companion, including URLs and instance IDs. Never guesses between multiple tabs.",
    z.object({}).strict(),
    async () => ({
      revision: null,
      value: { instances: await browser.instances() },
    }),
    true,
  );
  tool(
    "list_datasets",
    "Search/page the Atlas catalog. A connected tab is required; custom JSON can be loaded separately with import_dataset.",
    z
      .object({ query: z.string().optional(), ...pagination, ...instance })
      .strict(),
    async (args) => {
      const result = await browser.execute(
          "list_datasets",
          args.instanceId ? { instanceId: args.instanceId } : {},
        ),
        query = (args.query || "").toLowerCase();
      const items = result.value.filter((item) =>
        `${item.name} ${item.slug} ${item.description} ${(item.tags || []).join(" ")}`
          .toLowerCase()
          .includes(query),
      );
      return {
        revision: result.revision,
        value: {
          items: items.slice(args.offset, args.offset + args.limit),
          total: items.length,
          nextOffset:
            args.offset + args.limit < items.length
              ? args.offset + args.limit
              : null,
        },
      };
    },
    true,
  );
  tool(
    "open_dataset",
    "Replace the tab assembly with a catalog slug. Preserve its example assembly, or use startEmpty to begin without placed parts.",
    schema("open_dataset"),
    command("open_dataset"),
  );
  tool(
    "import_dataset",
    "Load a custom WASP aggregation JSON into the same Atlas tab. Supply exactly one of path (absolute local file on this computer) or data (JSON object). Uses the UI upload validation and reports Mode-0 compatibility warnings. Preserves placed parts unless startEmpty=true.",
    schema("import_dataset")
      .extend({
        data: z.record(z.string(), z.unknown()).optional(),
        path: z.string().min(1).optional(),
      })
      .refine(
        (args) => Boolean(args.path) !== Boolean(args.data),
        "Supply exactly one of path or data",
      ),
    async (args) => {
      const { path, ...input } = args;
      if (path) {
        input.data = await readJSON(resolve(path));
        input.filename = basename(path);
      }
      return browser.execute("import_dataset", input);
    },
  );
  tool(
    "inspect_assembly",
    "Inspect summary, base parts, placed parts or rules in the actual Atlas tab, without meshes.",
    schema("inspect_assembly"),
    command("inspect_assembly"),
    true,
  );
  tool(
    "preview_placements",
    "Read valid placements for one named part at an exact parent connection. No parts are added.",
    schema("preview_placements"),
    command("preview_placements"),
    true,
  );
  tool(
    "place_part",
    "Place a seed into an empty assembly, or attach using all three explicit attachment IDs. Uses the latest expectedRevision.",
    schema("place_part"),
    command("place_part"),
  );
  tool(
    "remove_part",
    "Remove an existing leaf through the same Atlas editing helper. Parents with children are rejected.",
    schema("remove_part"),
    command("remove_part"),
  );
  tool(
    "export_assembly",
    "Return the same Atlas Light JSON as the Download button. Custom datasets remain local unless explicitly exported.",
    schema("export_assembly"),
    command("export_assembly"),
    true,
  );
  tool(
    "snapshot_viewer",
    "Return a native PNG image from the actual tab canvas, with its current, preset or absolute custom camera.",
    schema("snapshot_viewer"),
    command("snapshot_viewer"),
  );
  return server;
}
