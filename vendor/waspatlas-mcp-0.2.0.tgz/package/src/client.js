import { protocolVersion, assertPayload } from "./protocol.js";

// Stable across router effects; reloading the document creates a new instance.
const id = globalThis.crypto.randomUUID();
export function startAtlasClient(hot, getBridge) {
  if (!hot) return () => {};
  let stopped = false,
    pending = Promise.resolve();
  const status = () => getBridge()?.status();
  const announce = () => {
    const state = status();
    if (!stopped && state)
      hot.send("wasp-atlas:hello", {
        id,
        version: protocolVersion,
        title: document.title,
        url: location.href,
        ...state,
      });
  };
  const receive = (message) => {
    if (stopped || message.instanceId !== id) return;
    pending = pending
      .catch(() => {})
      .then(async () => {
        const guard = () => {
          if (stopped || Date.now() >= message.deadline)
            throw new Error(
              "Atlas command expired or disconnected before execution.",
            );
        };
        let result;
        try {
          guard();
          const bridge = getBridge();
          if (!bridge) throw new Error("Atlas interface is not ready.");
          let body = await bridge.execute(
            message.command.tool,
            message.command.arguments,
            message.deadline,
          );
          if (
            ["open_dataset", "import_dataset"].includes(message.command.tool)
          ) {
            const load = body.value;
            while (true) {
              guard();
              const current = status();
              if (current?.requestId === load.requestId) {
                if (current.error) throw new Error(current.error);
                if (current.ready) {
                  body = await getBridge().execute(
                    "inspect_assembly",
                    {},
                    message.deadline,
                  );
                  if (load.warnings)
                    body.value = { ...body.value, warnings: load.warnings };
                  break;
                }
              }
              await new Promise((resolve) => setTimeout(resolve, 25));
            }
          }
          result = { ok: true, ...body };
          assertPayload(result);
        } catch (error) {
          result = {
            ok: false,
            revision: status()?.revision ?? null,
            error: {
              code: error.message.includes("stale_revision")
                ? "stale_revision"
                : "atlas_error",
              message: error.message,
            },
          };
        }
        if (!stopped) {
          hot.send("wasp-atlas:result", {
            requestId: message.requestId,
            result,
          });
          announce();
        }
      });
  };
  hot.on("wasp-atlas:command", receive);
  hot.on("vite:ws:connect", announce);
  announce();
  const heartbeat = setInterval(announce, 3000);
  const stop = () => {
    if (stopped) return;
    stopped = true;
    clearInterval(heartbeat);
    hot.off("wasp-atlas:command", receive);
    hot.off("vite:ws:connect", announce);
    hot.send("wasp-atlas:bye", { id });
  };
  hot.dispose(stop);
  return stop;
}
