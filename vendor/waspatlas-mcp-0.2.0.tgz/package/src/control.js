import { readFile, stat } from "node:fs/promises";
import { prefix, protocolVersion, assertPayload } from "./protocol.js";
import { connectionFile } from "./paths.js";

export class AtlasControl {
  constructor({ file = connectionFile() } = {}) {
    this.file = file;
    this.pending = Promise.resolve();
  }
  async request(path, data) {
    const descriptor = JSON.parse(await readFile(this.file, "utf8"));
    const url = new URL(descriptor.url);
    if (
      url.protocol !== "http:" ||
      !["127.0.0.1", "localhost", "[::1]"].includes(url.hostname) ||
      url.pathname !== prefix ||
      url.search ||
      url.hash ||
      url.username ||
      url.password ||
      !/^[0-9a-f]{64}$/.test(descriptor.token) ||
      descriptor.version !== protocolVersion
    )
      throw new Error(
        "Invalid local control connection file or protocol version.",
      );
    if (data) assertPayload(data);
    const response = await fetch(`${url.href}${path}`, {
      method: data ? "POST" : "GET",
      headers: {
        Authorization: `Bearer ${descriptor.token}`,
        ...(data ? { "Content-Type": "application/json" } : {}),
      },
      body: data ? JSON.stringify(data) : undefined,
      redirect: "error",
      signal: AbortSignal.timeout(65000),
    });
    const body = await response.json();
    if (!response.ok)
      throw new Error(
        body.error || `Local control returned ${response.status}`,
      );
    return body;
  }
  list() {
    return this.request("/instances");
  }
  call(instanceId, tool, args) {
    const result = this.pending
      .catch(() => {})
      .then(() => this.request("/call", { instanceId, tool, arguments: args }));
    this.pending = result.catch(() => {});
    return result;
  }
}
export async function readJSON(path) {
  const info = await stat(path);
  if (!info.isFile() || info.size > 64 * 1024 * 1024)
    throw new Error("Input must be a JSON file no larger than 64 MiB.");
  const data = JSON.parse(await readFile(path, "utf8"));
  if (!data || typeof data !== "object" || Array.isArray(data))
    throw new Error("Input file must contain a JSON object.");
  return data;
}
