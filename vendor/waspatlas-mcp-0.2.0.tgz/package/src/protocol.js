import * as z from "zod/v4";
export const protocolVersion = "1.0";
export const prefix = "/__wasp_atlas_control";
export const maxPayloadBytes = 64 * 1024 * 1024;
export const index = z.number().int().nonnegative().safe();
export const partId = z.union([z.number().int().safe(), z.string().min(1)]);
export const pagination = {
  offset: index.default(0),
  limit: index.min(1).max(100).default(20),
};
export const expectedRevision = z
  .string()
  .min(1)
  .describe(
    "Current opaque revision from inspection or the previous edit, including manual changes.",
  );
const vector = z.tuple([z.number(), z.number(), z.number()]);
export const controlTools = {
  get_status: z.object({}).strict(),
  list_datasets: z.object({}).strict(),
  open_dataset: z
    .object({
      slug: z.string().min(1),
      startEmpty: z.boolean().default(false),
      expectedRevision,
    })
    .strict(),
  import_dataset: z
    .object({
      data: z.record(z.string(), z.unknown()),
      filename: z.string().default("aggregation.json"),
      name: z.string().optional(),
      byPart: z
        .record(z.string(), z.string().regex(/^#[0-9a-fA-F]{6}$/))
        .optional(),
      startEmpty: z.boolean().default(false),
      expectedRevision,
    })
    .strict(),
  inspect_assembly: z
    .object({
      view: z
        .enum(["summary", "base_parts", "parts", "rules"])
        .default("summary"),
      partName: z.string().optional(),
      partId: partId.optional(),
      ...pagination,
    })
    .strict(),
  preview_placements: z
    .object({
      partName: z.string().min(1),
      parentPartId: partId,
      connectionId: index,
      ...pagination,
    })
    .strict(),
  place_part: z
    .object({
      expectedRevision,
      partName: z.string().min(1),
      parentPartId: partId.optional(),
      connectionId: index.optional(),
      connectionBId: index.optional(),
    })
    .strict(),
  remove_part: z.object({ expectedRevision, partId }).strict(),
  export_assembly: z.object({}).strict(),
  snapshot_viewer: z
    .object({
      expectedRevision: expectedRevision.optional(),
      view: z
        .enum(["isometric", "top", "bottom", "front", "back", "left", "right"])
        .optional(),
      camera: z
        .object({
          position: vector,
          target: vector,
          up: vector.optional(),
          fov: z.number().gt(0).lt(180).optional(),
        })
        .strict()
        .optional(),
    })
    .strict(),
};
export const commandSchema = z
  .object({
    tool: z.enum(Object.keys(controlTools)),
    arguments: z.record(z.string(), z.unknown()).default({}),
  })
  .strict();
export const instanceSchema = z.object({
  id: z.uuid(),
  version: z.literal(protocolVersion),
  title: z.string(),
  url: z.string(),
  revision: z.string(),
  ready: z.boolean(),
  loading: z.boolean(),
  error: z.string().nullable(),
  slug: z.string(),
  requestId: z.string().nullable(),
  busy: z.boolean(),
});
export function payloadBytes(value) {
  return new TextEncoder().encode(JSON.stringify(value)).byteLength;
}
export function assertPayload(value) {
  if (payloadBytes(value) > maxPayloadBytes)
    throw new Error(
      "Atlas payload exceeds 64 MiB; use paginated inspections and a smaller dataset.",
    );
}
