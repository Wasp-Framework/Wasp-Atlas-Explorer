/** Attach to the current Atlas document; never opens a separate browser. */
export function startAtlasClient(
  hot: any,
  getBridge: () =>
    | {
        status(): any;
        execute(command: string, args?: any, deadline?: number): Promise<any>;
      }
    | undefined,
): () => void;
