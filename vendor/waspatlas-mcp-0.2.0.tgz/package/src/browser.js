/** Local companion connection. The selected browser tab owns the model and renderer. */
import { readFile, access } from "node:fs/promises";
import { dirname, resolve, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { AtlasControl } from "./control.js";
import { atlasControlPlugin } from "./vite-plugin.js";

export class AtlasBrowser {
  constructor({
    appDir = process.env.WASPATLAS_APP_DIR,
    file,
    autoStart = process.env.WASPATLAS_AUTOSTART !== "0",
    port = Number(process.env.WASPATLAS_PORT || 5185),
  } = {}) {
    this.appDir = appDir;
    this.control = new AtlasControl({ file });
    this.autoStart = autoStart;
    this.port = port;
  }
  async ensure() {
    try {
      await this.control.list();
      return;
    } catch (error) {
      if (!this.autoStart)
        throw new Error(
          `Start Atlas with npm run dev:control first. ${error.message}`,
        );
    }
    if (this.starting) return this.starting;
    this.starting = (async () => {
      const parent = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
      let root = this.appDir && resolve(this.appDir);
      if (!root)
        for (const name of ["Wasp-Atas-Explorer", "Wasp-Atlas-Explorer"]) {
          const candidate = join(parent, name);
          try {
            await access(join(candidate, "vite.config.js"));
            root = candidate;
            break;
          } catch {}
        }
      if (!root)
        throw new Error(
          "Atlas checkout not found. Set WASPATLAS_APP_DIR to its absolute folder and run npm ci there, or start npm run dev:control separately.",
        );
      const vite = await import(
        pathToFileURL(join(root, "node_modules/vite/dist/node/index.js")).href
      ).catch(() => {
        throw new Error(`Install Atlas dependencies first: npm ci in ${root}`);
      });
      // The server uses this exact companion's bridge. Avoid enabling a second plugin from the app config.
      const previous = process.env.WASP_ATLAS_CONTROL;
      delete process.env.WASP_ATLAS_CONTROL;
      try {
        this.ownedServer = await vite.createServer({
          root,
          configFile: join(root, "vite.config.js"),
          plugins: [atlasControlPlugin(true)],
          server: { host: "127.0.0.1", port: this.port, strictPort: true },
          logLevel: "silent",
        });
      } finally {
        if (previous !== undefined) process.env.WASP_ATLAS_CONTROL = previous;
      }
      try {
        await this.ownedServer.listen();
        for (let attempt = 0; attempt < 100; attempt++) {
          try {
            await this.control.list();
            return;
          } catch {
            await new Promise((resolve) => setTimeout(resolve, 20));
          }
        }
        throw new Error("Atlas bridge did not become ready.");
      } catch (error) {
        await this.ownedServer.close();
        this.ownedServer = null;
        throw error;
      }
    })().finally(() => {
      this.starting = null;
    });
    return this.starting;
  }
  async instances() {
    await this.ensure();
    return (await this.control.list()).instances;
  }
  async choose(requested) {
    const instances = await this.instances(),
      chosen = requested || this.selected;
    let entry = instances.find((instance) => instance.id === chosen);
    if (requested && !entry)
      throw new Error(
        "Selected Atlas tab is unavailable. Call list_instances.",
      );
    if (!entry && instances.length === 1) entry = instances[0];
    if (!entry)
      throw new Error(
        instances.length
          ? "Multiple Atlas tabs are open. Supply an exact instanceId from list_instances."
          : "Open the URL returned by open_atlas in ChatGPT’s built-in browser first. No external browser is required.",
      );
    this.selected = entry.id;
    return entry;
  }
  async open({ instanceId } = {}) {
    await this.ensure();
    const entries = await this.instances();
    if (entries.length || instanceId) {
      const entry = await this.choose(instanceId);
      const result = await this.control.call(entry.id, "get_status", {});
      if (!result.ok) throw new Error(result.error.message);
      return {
        ...result.value,
        instanceId: entry.id,
        connected: true,
        url: entry.url,
      };
    }
    const descriptor = JSON.parse(await readFile(this.control.file, "utf8"));
    return {
      revision: null,
      ready: false,
      connected: false,
      url: `${new URL(descriptor.url).origin}/?mcp=1`,
      message:
        "Open this URL in ChatGPT’s built-in browser, then inspect the assembly or call open_atlas again. This MCP does not launch an external browser.",
    };
  }
  async status() {
    const entry = await this.choose();
    const result = await this.control.call(entry.id, "get_status", {});
    if (!result.ok) throw new Error(result.error.message);
    return { ...result.value, instanceId: entry.id, url: entry.url };
  }
  async execute(command, args = {}) {
    const { instanceId, ...arguments_ } = args,
      entry = await this.choose(instanceId);
    const result = await this.control.call(entry.id, command, arguments_);
    if (!result.ok) throw new Error(result.error.message);
    const { ok, ...body } = result;
    return body;
  }
  async close() {
    await this.starting?.catch(() => {});
    await this.ownedServer?.close();
    this.ownedServer = null;
    this.selected = null;
  }
}
