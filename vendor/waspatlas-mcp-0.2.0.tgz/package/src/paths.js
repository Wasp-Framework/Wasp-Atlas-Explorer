import { homedir } from "node:os";
import { resolve } from "node:path";
export const connectionFile = () =>
  resolve(
    process.env.WASPATLAS_CONNECTION_FILE ||
      `${homedir()}/.local/state/waspatlas-mcp/connection.json`,
  );
