import { randomBytes, timingSafeEqual } from "node:crypto";
import { mkdir, writeFile, rename, readFile, unlink } from "node:fs/promises";
import { dirname } from "node:path";
import { prefix, maxPayloadBytes, protocolVersion } from "./protocol.js";
import { connectionFile } from "./paths.js";
import { ControlBroker } from "./broker.js";

export function accessAllowed(request, token) {
  if (request.headers.origin || request.headers["sec-fetch-site"]) return false;
  if (
    !/^(127\.0\.0\.1|localhost|\[::1\]):\d+$/.test(request.headers.host || "")
  )
    return false;
  const actual = Buffer.from(request.headers.authorization || ""),
    expected = Buffer.from(`Bearer ${token}`);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
async function body(request) {
  const chunks = [];
  let size = 0,
    tooLarge = false;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maxPayloadBytes) {
      tooLarge = true;
      chunks.length = 0;
    }
    if (!tooLarge) chunks.push(chunk);
  }
  if (tooLarge) throw new Error("Control payload exceeds 64 MiB");
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}
function json(response, status, data) {
  response.statusCode = status;
  response.setHeader("Content-Type", "application/json");
  response.setHeader("Cache-Control", "no-store");
  response.end(JSON.stringify(data));
}
export function atlasControlPlugin(enabled = false) {
  return {
    name: "wasp-atlas-control",
    config(config, environment) {
      return {
        define: {
          __ATLAS_CONTROL_ENABLED__: JSON.stringify(
            enabled &&
              environment.command === "serve" &&
              !environment.isPreview,
          ),
        },
        server: {
          fs: {
            deny: [
              ...(config.server?.fs?.deny || [
                ".env",
                ".env.*",
                "*.{crt,pem}",
                "**/.git/**",
              ]),
              "**/.local/**",
              "**/.wasp-control/**",
              connectionFile().replaceAll("\\", "/"),
            ],
          },
        },
      };
    },
    configureServer(server) {
      if (!enabled) return;
      if (
        !["127.0.0.1", "localhost", "::1"].includes(server.config.server.host)
      )
        throw new Error(
          "Atlas control requires an explicit loopback-only host.",
        );
      const hmr = server.config.server.hmr;
      if (
        !server.httpServer ||
        server.config.server.https ||
        hmr === false ||
        server.config.server.ws === false ||
        (typeof hmr === "object" &&
          (hmr.port ||
            hmr.server ||
            (hmr.host &&
              !["127.0.0.1", "localhost", "::1"].includes(hmr.host))))
      )
        throw new Error(
          "Control requires standalone loopback HTTP with same-server HMR.",
        );
      const token = randomBytes(32).toString("hex"),
        broker = new ControlBroker(),
        peers = new WeakSet();
      server.ws.on("wasp-atlas:hello", (data, peer) => {
        if (!peers.has(peer)) {
          peers.add(peer);
          peer.socket.on("close", () => broker.disconnect(peer));
        }
        broker.announce(data, peer);
      });
      server.ws.on("wasp-atlas:result", (data, peer) =>
        broker.complete(data, peer),
      );
      server.ws.on("wasp-atlas:bye", (_, peer) => broker.disconnect(peer));
      // Atlas also supports older Vite installations. Enforce websocket origin
      // isolation here rather than relying on Vite's version-specific checks.
      const protectUpgrade = (request, socket) => {
        const host = request.headers.host || "";
        if (
          !/^(127\.0\.0\.1|localhost|\[::1\]):\d+$/.test(host) ||
          (request.headers.origin &&
            request.headers.origin !== `http://${host}`)
        )
          socket.destroy();
      };
      server.httpServer.prependListener("upgrade", protectUpgrade);
      const path = connectionFile();
      server.httpServer.once("listening", () => {
        void (async () => {
          const address = server.httpServer.address();
          if (
            !address ||
            typeof address === "string" ||
            !["127.0.0.1", "::1"].includes(address.address)
          )
            throw new Error("Control listener is not loopback-only.");
          await mkdir(dirname(path), { recursive: true, mode: 0o700 });
          const temporary = `${path}.${token.slice(0, 12)}.tmp`;
          await writeFile(
            temporary,
            JSON.stringify({
              url: `http://${address.address === "::1" ? "[::1]" : "127.0.0.1"}:${address.port}${prefix}`,
              token,
              version: protocolVersion,
            }),
            { mode: 0o600, flag: "wx" },
          );
          await rename(temporary, path);
          server.config.logger.info(
            `Atlas MCP bridge ready. Connection file: ${path}`,
          );
        })().catch((error) => {
          server.config.logger.error(String(error));
          void server.close();
        });
      });
      server.httpServer.once("close", () => {
        broker.close();
        void (async () => {
          if (JSON.parse(await readFile(path, "utf8")).token === token)
            await unlink(path);
        })().catch(() => {});
      });
      server.middlewares.use(async (request, response, next) => {
        const route = request.url?.split("?")[0] || "";
        if (route !== prefix && !route.startsWith(`${prefix}/`)) return next();
        if (!accessAllowed(request, token))
          return json(response, 403, {
            error:
              "Local bearer authentication required; browser HTTP requests are not accepted.",
          });
        try {
          if (route === `${prefix}/instances` && request.method === "GET")
            return json(response, 200, {
              version: protocolVersion,
              instances: broker.list(),
            });
          if (route === `${prefix}/call` && request.method === "POST") {
            const { instanceId, ...command } = await body(request);
            if (typeof instanceId !== "string")
              throw new Error("instanceId is required");
            return json(response, 200, await broker.call(instanceId, command));
          }
          json(response, 404, { error: "Unknown control endpoint or method" });
        } catch (error) {
          json(response, 400, {
            error: error instanceof Error ? error.message : String(error),
          });
        }
      });
    },
  };
}
