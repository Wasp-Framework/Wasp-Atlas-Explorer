# Wasp Atlas MCP

Desktop MCP control of the **public https://www.wasp-atlas.net website** in
ChatGPT's built-in browser. Atlas is never hosted locally. Version 0.3 removes
the local Atlas/Vite workflow from version 0.2.

The public site's existing `?mcp=1` command interface owns the assembly, camera,
renderer, imports and export. This MCP forwards explicit commands into the paired
public browser tab. It has no WaspJS model and does not start an external browser.

## Setup

Requires Node.js 22+ and this repository. **No Atlas checkout, local Atlas app,
Vite server or production Chromium installation is required.**

```sh
git clone https://github.com/Wasp-Framework/waspatlas-mcp.git
cd waspatlas-mcp
npm ci --omit=dev
```

Configure a local stdio MCP host using absolute paths:

```json
{
  "mcpServers": {
    "waspatlas": {
      "command": "/absolute/path/to/node",
      "args": ["/absolute/path/to/waspatlas-mcp/src/index.js"]
    }
  }
}
```

Use `command -v node` to locate Node if needed. The MCP host starts and stops the
process; do not start a second process on the same port. **Reconnect/restart the
existing Atlas MCP after updating** so its tools and instructions reload.

### Pair the public website

1. Call `open_atlas`. It returns a **public `https://www.wasp-atlas.net/?mcp=1#…`
   pairing link**.
2. Open that link in **ChatGPT's built-in browser**.
3. Click **Connect MCP** on the public page. If the browser asks to allow the
   desktop/loopback connection, allow it for Atlas. No security settings or
   certificate exceptions need to be disabled.
4. Call `open_atlas` again or `list_instances`, then inspect/load/build normally.

The Atlas UI and its assets come from the public website. Only the desktop MCP
process runs locally. Its authenticated loopback WebSocket carries commands and
results; it serves **no Atlas webpage**, project files or development server.
There is no hosted relay, public MCP port or new cloud service. This remains a
local **stdio MCP host configuration**, not a remote HTTPS MCP endpoint.

Pairing credentials are placed in the URL **fragment**, which is not sent to the
public web server. The page removes them from its URL after reading them. Do not
share the pairing link. The connection accepts only the exact public Atlas
origins and the correct random process token. Ordinary visits to Atlas expose no
MCP connection and do not contact the desktop service.

The public page shows connection status and a **Disconnect MCP** button. After a
socket disconnect, **Connect MCP** can reconnect to the same running process.
After restarting the MCP or reloading a page without its pairing fragment, get a
fresh link from `open_atlas`. Export before reloading or navigating away from an
assembly; custom uploads are in-memory browser state.

If ChatGPT's built-in browser capability is unavailable, this MCP cannot restore
that host capability. A browser that blocks desktop/loopback connections must
permit that connection for this integration; no external browser is launched as
a fallback.

## Custom datasets

`import_dataset` accepts the latest opaque `expectedRevision` and **exactly one**
of:

- `path`: a JSON file on the computer running the desktop MCP. Use an absolute
  local path; the MCP transfers its data directly into the public Atlas tab.
- `data`: a WASP aggregation JSON object supplied inline.

```json
{
  "path": "/absolute/path/to/my-dataset.json",
  "expectedRevision": "copy-the-current-revision",
  "startEmpty": false
}
```

Optional fields are `name`, `filename` for inline data, `byPart` (part names to
six-digit hex colors) and `instanceId`. `startEmpty: false` preserves supplied
placed instances; `true` clears those instances but keeps the imported parts and
rules. Empty imports stay empty and receive no random growth.

Imports run through the **same sanitizer and loader as the public upload UI**.
Unsupported constraints are rejected; Mode-0 conversion/Field warnings are
returned and displayed. Validation finishes before replacing the active upload.
The source file is unchanged. Imports do not add anything to the public Atlas
collection, GitHub or a relay. Custom imports do not wait for the public catalog
to respond.

A ChatGPT attachment must be available as a file on the desktop MCP's computer or
supplied as JSON. A file existing only in another sandbox is not a local host
path. Inputs and results are bounded by a 64 MiB transport cap, including JSON
encoding overhead. Catalog geometry, stock, attributes and compatibility follow
the site's installed WaspJS version.

## Tools

| Tool                 | Purpose                                                                     |
| -------------------- | --------------------------------------------------------------------------- |
| `open_atlas`         | Return a public-site pairing link or inspect/select a connected public tab. |
| `list_instances`     | List paired public Atlas tabs and exact instance IDs.                       |
| `list_datasets`      | Search/page the public Atlas catalog.                                       |
| `open_dataset`       | Open a catalog slug, preserving or clearing its example assembly.           |
| `import_dataset`     | Import a custom JSON file or object into the public tab.                    |
| `inspect_assembly`   | Read summary, base parts, placed parts or rules without meshes.             |
| `preview_placements` | Inspect valid poses at one exact parent connection.                         |
| `place_part`         | Seed an empty assembly or attach with all three connection IDs.             |
| `remove_part`        | Remove a leaf using the existing Atlas helper.                              |
| `export_assembly`    | Return the same Atlas Light JSON as the Download button.                    |
| `snapshot_viewer`    | Return a native PNG from the actual public tab renderer/camera.             |

There are **11 tools**. A sole connected tab can be selected implicitly. With
multiple tabs and no previous live selection, provide an exact `instanceId` from
`list_instances`. No arbitrary browser is attached through a debugging port.
Stopping the MCP disconnects the channel and never closes browser tabs.

Edits require the latest opaque `expectedRevision` from inspection or the last
successful edit. Manual edits, dataset loads and document reloads invalidate old
tokens. Rejected edits and snapshots do not advance the revision. Commands are
queued and expire before late execution; after a timeout or disconnect inspect
before retrying, because an operation that already started may have completed.

Inspect names and connection IDs before placing. A seed requires an empty
assembly. An attachment requires `parentPartId`, `connectionId`, `connectionBId`
together. IDs refer to authored Wasp slots, not inferred physical openings.
Coordinates retain dataset units. Leaf-only removal, collision behavior and
finite stock match the public app. No routing, random-growth tool, split/join or
Configurator-specific behavior is added.

## Snapshots

Snapshots use the current camera unless `view` or `camera` is supplied. Presets:
`isometric`, `top`, `bottom`, `front`, `back`, `left`, `right`. They fit the placed
geometry. Custom cameras use absolute dataset coordinates:

```json
{
  "camera": {
    "position": [6, -6, 5],
    "target": [1, 1, 0],
    "up": [0, 0, 1],
    "fov": 45
  }
}
```

The native PNG and its metadata come from the existing renderer in one browser
task. No second model, geometry quota or screenshot scene is created.

## Configuration and migration

- `WASPATLAS_PORT` changes the desktop MCP connection port (default **5186**).
  This port is a command channel, **not a local Atlas URL**. An occupied port is
  refused. Port 0 is useful for isolated tests.
- `WASPATLAS_URL` can select the public HTTPS apex or www Atlas origin. Localhost,
  HTTP and unrelated websites are refused.
- Remove old `WASPATLAS_APP_DIR`, `WASPATLAS_AUTOSTART`,
  `WASPATLAS_CONNECTION_FILE` and `WASPATLAS_HEADLESS` entries. They are unused.
- No `npm run dev:control`, private connection file or separate local Atlas
  instance is used. The old localhost workflow is removed rather than retained
  as a fallback.
- The public deployment must include the 0.3 browser connection client. The
  existing window command interface alone does not transport requests from a
  desktop process into a browser tab.

## Develop and verify

Normal MCP use does not depend on Playwright. For development tests only:

```sh
npm ci
npx playwright install chromium
npm test
npm run format:check
```

The integration suite builds the production Explorer into a disposable fixture,
loads it under the public HTTPS origin in a test browser, and runs real stdio MCP
calls over the authenticated WebSocket. No local Atlas web server is started.
It covers custom files/data, retained and empty imports, invalid/stale imports,
manual edits, snapshots, exports, multiple tabs, and blocked public-catalog
requests. Separate tests reject wrong tokens/origins, confirm no local Atlas page
is served, and cover queue expiry and reply ownership.

`npm run check:web` is an opt-in **live deployed-site integration test** using a
separate disposable headless test browser and an isolated MCP port. It builds a
two-part assembly from the public catalog, round-trips a custom import, verifies
a native PNG, then closes only its test session. It needs development test
dependencies and network access; it does not touch user tabs or publish data.

The Explorer pins this package's browser client in a local archive. To refresh
that build dependency after changing the client:

```sh
npm pack --pack-destination /absolute/path/to/Wasp-Atlas-Explorer/vendor
# In the Explorer checkout:
npm install --save-dev ./vendor/waspatlas-mcp-0.3.0.tgz
npm test
npm run typecheck
npm run build
```

Packing is local, does not publish to npm, and is needed only by application
maintainers. **End users run the public website, never a local Explorer checkout.**
