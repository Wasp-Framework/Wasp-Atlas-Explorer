import { randomUUID } from "node:crypto";
import {
  assertPayload,
  commandSchema,
  controlTools,
  instanceSchema,
} from "./protocol.js";

export class ControlBroker {
  instances = new Map();
  pending = new Map();
  queues = new Map();
  constructor(timeoutMs = 60000) {
    this.timeoutMs = timeoutMs;
  }
  announce(raw, peer) {
    const parsed = instanceSchema.safeParse(raw);
    if (!parsed.success) return;
    const current = this.instances.get(parsed.data.id);
    if (current && current.peer !== peer) return;
    this.instances.set(parsed.data.id, { info: parsed.data, peer });
  }
  list() {
    return [...this.instances.values()].map(({ info }) => info);
  }
  disconnect(peer) {
    for (const [id, entry] of this.instances)
      if (entry.peer === peer) this.instances.delete(id);
    for (const [id, entry] of this.pending)
      if (entry.peer === peer)
        this.finish(id, {
          ok: false,
          error: {
            code: "disconnected",
            message: "Tab disconnected; inspect before retrying any edit.",
          },
        });
  }
  call(instanceId, raw) {
    const command = commandSchema.parse(raw);
    command.arguments = controlTools[command.tool].parse(command.arguments);
    assertPayload(command);
    const deadline = Date.now() + this.timeoutMs;
    const previous = this.queues.get(instanceId) || Promise.resolve();
    const result = previous
      .catch(() => {})
      .then(() => this.dispatch(instanceId, command, deadline));
    const tail = result.catch(() => {});
    this.queues.set(instanceId, tail);
    tail.finally(() => {
      if (this.queues.get(instanceId) === tail) this.queues.delete(instanceId);
    });
    return result;
  }
  dispatch(instanceId, command, deadline) {
    const entry = this.instances.get(instanceId);
    if (!entry)
      throw new Error(
        "Instance not found; call list_instances and choose a connected tab.",
      );
    if (Date.now() >= deadline)
      throw new Error("Command expired in queue before execution.");
    const requestId = randomUUID();
    return new Promise((resolve) => {
      const timer = setTimeout(
        () =>
          this.finish(requestId, {
            ok: false,
            error: {
              code: "timeout",
              message:
                "Command timed out; outcome unknown. Inspect get_status before retrying an edit.",
            },
          }),
        deadline - Date.now(),
      );
      this.pending.set(requestId, { peer: entry.peer, resolve, timer });
      try {
        entry.peer.send("wasp-atlas:command", {
          instanceId,
          requestId,
          deadline,
          command,
        });
      } catch {
        this.finish(requestId, {
          ok: false,
          error: {
            code: "disconnected",
            message: "Could not reach the selected tab.",
          },
        });
      }
    });
  }
  complete(raw, peer) {
    if (
      !raw ||
      typeof raw.requestId !== "string" ||
      this.pending.get(raw.requestId)?.peer !== peer
    )
      return;
    const result = raw.result;
    if (!result || typeof result.ok !== "boolean") return;
    try {
      assertPayload(result);
      this.finish(raw.requestId, result);
    } catch (error) {
      this.finish(raw.requestId, {
        ok: false,
        error: { code: "payload_too_large", message: error.message },
      });
    }
  }
  finish(id, result) {
    const entry = this.pending.get(id);
    if (!entry) return;
    this.pending.delete(id);
    clearTimeout(entry.timer);
    entry.resolve(result);
  }
  close() {
    this.instances.clear();
    for (const id of this.pending.keys())
      this.finish(id, {
        ok: false,
        error: {
          code: "server_stopped",
          message: "Control server stopped; inspect before retrying.",
        },
      });
  }
}
