import { protocolVersion, assertPayload } from "./protocol.js";
const publicOrigins = new Set([
  "https://www.wasp-atlas.net",
  "https://wasp-atlas.net",
]);

export function startAtlasClient(getBridge, { onStatus = () => {} } = {}) {
  const id = crypto.randomUUID(),
    url = new URL(location.href),
    fragment = new URLSearchParams(url.hash.slice(1));
  const port = Number(fragment.get("atlasMcpPort")),
    token = fragment.get("atlasMcpToken");
  fragment.delete("atlasMcpPort");
  fragment.delete("atlasMcpToken");
  url.hash = fragment.toString();
  history.replaceState(history.state, "", url.href);
  let socket,
    pending = Promise.resolve(),
    heartbeat,
    activeAbort,
    generation = 0,
    disposed = false;
  const emit = (state, message) => {
    if (!disposed) onStatus({ state, message });
  };
  const paired =
    publicOrigins.has(url.origin) &&
    Number.isInteger(port) &&
    port > 0 &&
    port <= 65535 &&
    /^[0-9a-f]{64}$/.test(token || "");
  const send = (event, data) => {
    if (socket?.readyState === WebSocket.OPEN)
      socket.send(JSON.stringify({ event, data }));
  };
  const announce = () => {
    const state = getBridge()?.status();
    if (state)
      send("wasp-atlas:hello", {
        id,
        version: protocolVersion,
        title: document.title,
        url: location.href,
        ...state,
      });
  };
  const disconnect = () => {
    generation++;
    activeAbort?.abort();
    clearInterval(heartbeat);
    send("wasp-atlas:bye", { id });
    socket?.close();
    socket = undefined;
    emit("disconnected", "MCP disconnected");
  };
  const connect = () => {
    if (disposed || !paired) return;
    disconnect();
    const current = ++generation;
    emit("connecting", "Connecting to desktop MCP…");
    const connection = (socket = new WebSocket(
      `ws://127.0.0.1:${port}/atlas-mcp`,
      ["wasp-atlas-v1", `auth.${token}`],
    ));
    connection.onopen = () => {
      if (current !== generation) return;
      announce();
      heartbeat = setInterval(announce, 3000);
      emit("connected", "MCP connected");
    };
    connection.onclose = () => {
      if (current !== generation) return;
      activeAbort?.abort();
      clearInterval(heartbeat);
      emit(
        "disconnected",
        "MCP disconnected. Reconnect the MCP or check browser permissions.",
      );
    };
    connection.onerror = () => {
      if (current === generation)
        emit(
          "error",
          "Could not connect. Check the MCP process and browser permission for the desktop connection.",
        );
    };
    connection.onmessage = (message) => {
      let packet;
      try {
        packet = JSON.parse(message.data);
      } catch {
        return;
      }
      if (
        packet.event !== "wasp-atlas:command" ||
        packet.data?.instanceId !== id
      )
        return;
      const request = packet.data;
      pending = pending
        .catch(() => {})
        .then(async () => {
          const abort = (activeAbort = new AbortController());
          const guard = () => {
            if (
              disposed ||
              current !== generation ||
              abort.signal.aborted ||
              Date.now() >= request.deadline
            )
              throw new Error(
                "Atlas command expired or disconnected before execution.",
              );
          };
          let result;
          try {
            guard();
            const bridge = getBridge();
            if (!bridge) throw new Error("Atlas interface is not ready.");
            let body = await bridge.execute(
              request.command.tool,
              request.command.arguments,
              request.deadline,
              abort.signal,
            );
            if (
              ["open_dataset", "import_dataset"].includes(request.command.tool)
            ) {
              const load = body.value;
              while (true) {
                guard();
                const state = getBridge()?.status();
                if (state?.requestId === load.requestId) {
                  if (state.error) throw new Error(state.error);
                  if (state.ready) {
                    body = await getBridge().execute(
                      "inspect_assembly",
                      {},
                      request.deadline,
                      abort.signal,
                    );
                    if (load.warnings)
                      body.value = { ...body.value, warnings: load.warnings };
                    break;
                  }
                }
                await new Promise((resolve) => setTimeout(resolve, 25));
              }
            }
            result = { ok: true, ...body };
            assertPayload(result);
          } catch (error) {
            result = {
              ok: false,
              revision: getBridge()?.status().revision ?? null,
              error: {
                code: error.message.includes("stale_revision")
                  ? "stale_revision"
                  : "atlas_error",
                message: error.message,
              },
            };
          } finally {
            if (activeAbort === abort) activeAbort = undefined;
          }
          if (!disposed && current === generation) {
            send("wasp-atlas:result", { requestId: request.requestId, result });
            announce();
          }
        });
    };
  };
  emit(
    paired ? "ready" : "unpaired",
    paired
      ? "Connect this public Atlas tab to your desktop MCP."
      : "Open the pairing link returned by your Atlas MCP to connect.",
  );
  return {
    connect,
    disconnect,
    dispose() {
      disconnect();
      disposed = true;
    },
  };
}
