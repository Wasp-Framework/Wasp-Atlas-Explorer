/** Public Atlas tab connection. No Atlas website, checkout or browser is hosted locally. */
import { createServer } from "node:http";
import { randomBytes, timingSafeEqual } from "node:crypto";
import { WebSocketServer } from "ws";
import { ControlBroker } from "./broker.js";
import { maxPayloadBytes, assertPayload } from "./protocol.js";

export const PUBLIC_ORIGINS = new Set([
  "https://www.wasp-atlas.net",
  "https://wasp-atlas.net",
]);
export const DEFAULT_ATLAS_URL = "https://www.wasp-atlas.net/";
const socketPath = "/atlas-mcp";
export class AtlasBrowser {
  constructor({
    url = process.env.WASPATLAS_URL || DEFAULT_ATLAS_URL,
    port = Number(process.env.WASPATLAS_PORT || 5186),
  } = {}) {
    this.url = new URL(url);
    if (
      !PUBLIC_ORIGINS.has(this.url.origin) ||
      this.url.username ||
      this.url.password
    )
      throw new Error(
        "Atlas MCP only connects to the public HTTPS wasp-atlas.net website.",
      );
    if (!Number.isInteger(port) || port < 0 || port > 65535)
      throw new Error("Invalid desktop MCP port.");
    this.port = port;
    this.token = randomBytes(32).toString("hex");
    this.broker = new ControlBroker();
  }
  async ensure() {
    if (this.http) return;
    if (this.starting) return this.starting;
    this.starting = (async () => {
      const http = createServer((_, response) => {
        response.writeHead(404, {
          "Cache-Control": "no-store",
          "Content-Type": "text/plain",
        });
        response.end(
          "This is an MCP connection channel, not an Atlas website.",
        );
      });
      const sockets = new WebSocketServer({
        noServer: true,
        maxPayload: maxPayloadBytes,
        perMessageDeflate: false,
        handleProtocols: (protocols) =>
          protocols.has("wasp-atlas-v1") ? "wasp-atlas-v1" : false,
      });
      http.on("upgrade", (request, socket, head) => {
        const protocols = (request.headers["sec-websocket-protocol"] || "")
          .split(",")
          .map((value) => value.trim());
        const supplied = Buffer.from(
            protocols.find((value) => value.startsWith("auth."))?.slice(5) ||
              "",
          ),
          expected = Buffer.from(this.token);
        if (
          request.url !== socketPath ||
          request.headers.host !== `127.0.0.1:${http.address()?.port}` ||
          !PUBLIC_ORIGINS.has(request.headers.origin) ||
          !protocols.includes("wasp-atlas-v1") ||
          supplied.length !== expected.length ||
          !timingSafeEqual(supplied, expected)
        ) {
          socket.end("HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n");
          return;
        }
        sockets.handleUpgrade(request, socket, head, (connection) =>
          sockets.emit("connection", connection, request),
        );
      });
      sockets.on("connection", (socket, request) => {
        const peer = {
          send: (event, data) => socket.send(JSON.stringify({ event, data })),
        };
        let alive = true;
        socket.on("pong", () => {
          alive = true;
        });
        const heartbeat = setInterval(() => {
          if (!alive) return socket.terminate();
          alive = false;
          socket.ping();
        }, 30000);
        socket.on("message", (data) => {
          try {
            const packet = JSON.parse(data.toString());
            if (packet.event === "wasp-atlas:hello") {
              if (new URL(packet.data.url).origin !== request.headers.origin)
                throw new Error("Origin mismatch");
              this.broker.announce(packet.data, peer);
            } else if (packet.event === "wasp-atlas:result")
              this.broker.complete(packet.data, peer);
            else if (packet.event === "wasp-atlas:bye")
              this.broker.disconnect(peer);
            else throw new Error("Unknown event");
          } catch {
            socket.close(1008, "Invalid Atlas message");
          }
        });
        socket.on("error", () => {});
        socket.on("close", () => {
          clearInterval(heartbeat);
          this.broker.disconnect(peer);
        });
      });
      try {
        await new Promise((resolve, reject) => {
          http.once("error", reject);
          http.listen(this.port, "127.0.0.1", resolve);
        });
      } catch (error) {
        sockets.close();
        http.close();
        throw new Error(
          `Could not start the desktop MCP connection on port ${this.port}: ${error.message}`,
        );
      }
      this.http = http;
      this.sockets = sockets;
    })().finally(() => {
      this.starting = null;
    });
    return this.starting;
  }
  async instances() {
    await this.ensure();
    return this.broker.list();
  }
  async choose(requested) {
    const instances = await this.instances(),
      chosen = requested || this.selected;
    let entry = instances.find((instance) => instance.id === chosen);
    if (requested && !entry)
      throw new Error(
        "Selected public Atlas tab is unavailable. Call list_instances.",
      );
    if (!entry && instances.length === 1) entry = instances[0];
    if (!entry)
      throw new Error(
        instances.length
          ? "Multiple Atlas tabs are connected. Supply an exact instanceId from list_instances."
          : "Open the public pairing URL from open_atlas in ChatGPT’s browser and click Connect MCP.",
      );
    this.selected = entry.id;
    return entry;
  }
  async open({ instanceId } = {}) {
    await this.ensure();
    if ((await this.instances()).length || instanceId) {
      const entry = await this.choose(instanceId);
      return { ...(await this.status(entry.id)), connected: true };
    }
    const url = new URL(this.url);
    url.searchParams.set("mcp", "1");
    url.hash = new URLSearchParams({
      atlasMcpPort: String(this.http.address().port),
      atlasMcpToken: this.token,
    }).toString();
    return {
      revision: null,
      ready: false,
      connected: false,
      url: url.href,
      message:
        "Open this public wasp-atlas.net pairing link in ChatGPT’s built-in browser and click Connect MCP. No local Atlas instance or external browser is started.",
    };
  }
  async status(instanceId) {
    const entry = await this.choose(instanceId),
      result = await this.broker.call(entry.id, {
        tool: "get_status",
        arguments: {},
      });
    if (!result.ok) throw new Error(result.error.message);
    return { ...result.value, instanceId: entry.id, url: entry.url };
  }
  async execute(command, args = {}) {
    const { instanceId, ...arguments_ } = args,
      entry = await this.choose(instanceId);
    assertPayload(arguments_);
    const result = await this.broker.call(entry.id, {
      tool: command,
      arguments: arguments_,
    });
    if (!result.ok) throw new Error(result.error.message);
    const { ok, ...body } = result;
    return body;
  }
  async close() {
    await this.starting?.catch(() => {});
    this.broker.close();
    for (const socket of this.sockets?.clients || []) socket.terminate();
    if (this.sockets)
      await new Promise((resolve) => this.sockets.close(resolve));
    if (this.http) await new Promise((resolve) => this.http.close(resolve));
    this.http = null;
    this.sockets = null;
    this.selected = null;
  }
}
