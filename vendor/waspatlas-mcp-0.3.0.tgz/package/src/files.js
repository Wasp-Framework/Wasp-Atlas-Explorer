import { readFile, stat } from "node:fs/promises";
import { maxPayloadBytes } from "./protocol.js";
export async function readJSON(path) {
  const info = await stat(path);
  if (!info.isFile() || info.size > maxPayloadBytes)
    throw new Error("Input must be a JSON file no larger than 64 MiB.");
  const data = JSON.parse(await readFile(path, "utf8"));
  if (!data || typeof data !== "object" || Array.isArray(data))
    throw new Error("Input file must contain a JSON object.");
  return data;
}
