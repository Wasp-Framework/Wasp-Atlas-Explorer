export type AtlasConnectionStatus = {
  state:
    | "ready"
    | "unpaired"
    | "connecting"
    | "connected"
    | "disconnected"
    | "error";
  message: string;
};
export type AtlasConnection = {
  connect(): void;
  disconnect(): void;
  dispose(): void;
};
export function startAtlasClient(
  getBridge: () =>
    | {
        status(): any;
        execute(
          command: string,
          args?: any,
          deadline?: number,
          signal?: AbortSignal,
        ): Promise<any>;
      }
    | undefined,
  options?: { onStatus?: (status: AtlasConnectionStatus) => void },
): AtlasConnection;
